﻿How to install Sigma?
https://sites.google.com/view/vector-sigma/

Sigma's command list?
https://sites.google.com/view/vector-sigma/command-list

Sigma's changelog?
https://sites.google.com/view/vector-sigma/changelog

Sigma's demonstrations?
https://sites.google.com/view/vector-sigma/showroom
